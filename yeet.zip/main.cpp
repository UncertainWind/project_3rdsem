#include<iostream>
#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
//#include"mainMemu.h"
#include"welcome.h"
int main()
{
    welcome(500,500);
}

